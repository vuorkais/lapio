#!/bin/bash
# a really simple encryption technique: https://en.wikipedia.org/wiki/Caesar_cipher
# "echo" is a bash command, and tr is a command line tool: https://en.wikipedia.org/wiki/Tr_(Unix)
echo 'mjd_stb_dtzwj_fs_fqq_xyfw_ljy_dtzw_lfrj_ts_lt_uqfd' | tr '[f-za-e]' '[a-z]'
