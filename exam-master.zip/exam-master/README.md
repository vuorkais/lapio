# Tools for the exam 

Please clone this project before you start the exam.

Contents of unix-like-wiki.html are taken from the Unix-like [Wikipedia page](https://en.wikipedia.org/wiki/Unix-like), released under CC-BY-SA:  http://creativecommons.org/licenses/by-sa/3.0/.
